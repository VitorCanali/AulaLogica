1. Calculadora Simples:
Eu fiz um código que o usuário informa 2 números.
exemplo : numero 1 = 10 numero 1 = 2
O computador faz os 4 cálculos básicos sozinhos.


2. Média Aritmética:
O computador pede para o usuário informar as 3 notas, quando ele fala as 3 notas o computador soma tudo e divide pelo numero de notas (3)


3. Conversão de Temperatura:
O computador pede para inserir os graus em Celsius e logo em seguida ele faz a conversão para o Fahrenheit, eu fiz usando a fórmula de conversão.

4. Área do Retângulo:
Eu fiz o computador pedir a base e a altura, e logo em seguida ele calcula a área multiplicando os números.

5. Antecessor e Sucessor:
Eu fiz o computador pedir 1 numero, quando esse numero é informado ele subtrai por 1 e da o resultado (antecessor) logo em seguida soma por 1 o numero informado e também da o resultado (sucessor).

6. Dobro e Metade:
Eu fiz o computador pedir para informar 1 numero e o computador multiplica e depois divide o numero, dando o dobro e a metade.

7. Cálculo de Salário:
Eu fiz o computador pedir as horas totais trabalhadas, depois o valor da hora e ele multiplica ambos para dar o salario total.

8. Conversão de Moeda:
Eu fiz o computador pedir o valor em real e a cotação do dólar, ai o computador divide o dólar por real e da o valor em dólar.

9. Cálculo do Salário com Aumento:
Eu fiz o computador pedir o salario atual do usuário e o percentual do aumento, ai o computador multiplica o salario atual com o percentual e depois divide por 100, logo em seguida ele soma esse numero que foi gerado na divisão e soma com o salário atual, gerando o novo salario.

10. Velocidade Média:
Eu fiz o computador pedir a distancia percorrida em KM e o tempo gasto, ai o computador divide a distancia com o tempo gasto, gerando a velocidade média do objeto.